#!/usr/bin/perl

# Copyright (c) 2017 Veritas Technologies LLC ALL RIGHTS RESERVED.
# UNPUBLISHED -- RIGHTS RESERVED UNDER THE COPYRIGHT
# LAWS OF THE UNITED STATES. USE OF A COPYRIGHT NOTICE
# IS PRECAUTIONARY ONLY AND DOES NOT IMPLY PUBLICATION
# OR DISCLOSURE.
#
# THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND
# TRADE SECRETS OF VERITAS SOFTWARE. USE, DISCLOSURE,
# OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
# EXPRESS WRITTEN PERMISSION OF VERITAS SOFTWARE.
#
# RESTRICTED RIGHTS LEGEND
# USE, DUPLICATION, OR DISCLOSURE BY THE GOVERNMENT IS
# SUBJECT TO RESTRICTIONS AS SET FORTH IN SUBPARAGRAPH
# (C) (1) (ii) OF THE RIGHTS IN TECHNICAL DATA AND
# COMPUTER SOFTWARE CLAUSE AT DFARS 252.227-7013.

# Set some variables that are needed through the script
# put the variables here .....
use FindBin;
use lib "$FindBin::Bin/../setup/lib";

require 'common_functions.pl';
require 'os_variables.pl';
require 'common_sf.pl';
require 'common_vcs.pl';
require 'common_install.pl';
require 'config_functions.pl';

$local_sys = qx/uname -n/;
chomp($local_sys);

# Set some OS specific variables
_OS_variables();
$remote_sh = $ssh;

set_tput();

$systems = "sys1 sys2 sys3 sys4";
print "Checking if loopydatadg is imported on $local_sys.\n\n";
my $is_imported = qx/$vxdg list | grep loopydatadg/;
chomp($is_imported);
if (!$is_imported){
	print "The loopydatadg disk group is not imported on this system.\n";
	print "Execute this script on the system where loopydatadg is imported.\n";
	print "Exiting without any changes.\n\n";
	exit;
}
print "Turning site consistency off for the disk group.\n\n";
_do("$vxdg -g loopydatadg set siteconsistent=off");
print "Removing the sites from the disk group.\n\n";
my @sitelist = qx/$vxprint -g loopydatadg -m | grep \^site | awk '{print \$2}'/;
chomp(@sitelist);
foreach (@sitelist){
	chomp($_);
	_do("$vxdg -g loopydatadg rmsite $_");
}
print "Removing site tags from the disks in loopydatadg.\n\n";
my @disklist = qx/$vxdisk list | grep loopydatadg | awk '{print \$1}'/;
chomp(@disklist);
foreach (@disklist){
	chomp($_);
	$site = qx/$vxdisk listtag $_ | grep -v NAME | awk '{print \$3}'/;
	chomp($site);
	_do("$vxdisk rmtag site=$site $_");
}
print "Removing the DCO and the second plex from loopydatavol.\n\n";
_do("$vxsnap -g loopydatadg -f unprepare loopydatavol");
_do("$vxplex -g loopydatadg -o rm dis loopydatavol-02");
print "Turning the siteconsistent and allsites features off for the volume.\n\n";
_do("$vxvol -g loopydatadg set siteconsistent=off loopydatavol");
_do("$vxvol -g loopydatadg set allsites=off loopydatavol");
print "Resetting the volume read policy.\n\n";
_do("$vxvol -g loopydatadg rdpol select loopydatavol");
print "Removing the unused disks from the disk group.\n\n";
$diskinuse = qx/$vxprint -g loopydatadg -htrqQ | grep loopydatavol-01 | grep -v ENABLE | awk '{print \$8}'/;
chomp($diskinuse);
foreach (@disklist){
	chomp($_);
	if ($_ ne $diskinuse) {
		_do("$vxdisk reclaim $_");
		$dmname = qx/$vxprint -g loopydatadg -d | grep $_ | awk '{print \$2}'/;
		chomp($dmname);
		_do("$vxdg -g loopydatadg rmdisk $dmname");
		_do("$vxdiskunsetup $_");
	}
}	
print "Removing system site assignments.\n\n";
@systems = split(/ /, $systems);
foreach (@systems){
	chomp($_);
	if ($_ eq $local_sys){
		_do("$vxdctl unset site");
	} else {
		_do("$remote_sh $_ $vxdctl unset site");
	}
}
