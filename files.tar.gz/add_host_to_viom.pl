#!/opt/VRTSsfmh/bin/perl
BEGIN { @INC = ("/opt/VRTSsfmh/lib/modules", "$ENV{PROGRAMW6432}\\Veritas\\VRTSsfmh\\lib\\modules", "$ENV{ProgramFiles}\\Veritas\\VRTSsfmh\\lib\\modules") }

use strict;
use Getopt::Long;
use File::Spec;
use JSON;

require VRTS::Paths;
require VRTS::CMD;
require VRTS::Util;
require VRTS::OS;
require VRTS::Logger;
require VRTS::Config;
require VRTS::SFMHCAT;
use VRTS::CGILOCALE;

## Global Variable declaration and Path setting
my $_installdir         = VRTS::Paths::get_path ("InstallDir");
my $_appdir             = VRTS::Paths::get_path ("AppDir");
my $appdirmh            = File::Spec->canonpath ($_appdir);
my $appdircs            = $appdirmh;
   $appdircs            =~ s/VRTSsfmh/VRTSsfmcs/;
my $installdirmh        = File::Spec->canonpath ($_installdir);
my $installdircs        = $installdirmh;
   $installdircs        =~ s/VRTSsfmh/VRTSsfmcs/;
my $sfm_resolve_conf    = VRTS::Paths::get_path ("SFMResolv");
my $atutil_command      = File::Spec->catfile   ($installdirmh, "bin", "atutil");
my $perl_command        = File::Spec->catfile   ($installdirmh, "bin", "perl");
$perl_command        = File::Spec->catfile   ($installdirmh, "bin", "perl.exe") if ($^O =~ /Win32/i);
my $sfme_command        = File::Spec->catfile   ($installdirmh, "bin", "sfme");
my $xprtlc              = File::Spec->catfile   ($installdirmh, "bin", "xprtlc");
my $devnull             = File::Spec->devnull();
my $ping                = File::Spec->catfile   ($installdirmh, "bin", "ping");
my $mh_logger;

## Global Variable declaration and Path setting Ends here

my %opts;
my $quiet=0;
my $mh_cred;
my $sfme;
my $MH_HOSTNAME = undef; 
my $cmd = undef;
my $out;
my $js;
my $obj;
my $hostid;
#task related variables
my $task_handler;
my %task_hash;
my $task_id;
my $TASK_SUPPORTED = 1;
my $cs = "mgt.example.com";
my $cs_config_name = "mgt.example.com";
my $cs_guid = "{00010050-5690-0a35-0000-000000000000}";
my $least_sup_mh_ver = "5.0.0.0";

my $log_path = VRTS::Paths::get_path("LogDir");
$mh_logger = new VRTS::Logger(Module => 'gendeploy',
                              Logdir => $log_path,
                              Level => 'debug',
                              Logfile => 'mhrun.log',
                              Logsize => 1024*1024,
                              UmiString => 'V-0000-0000');

# We need to ensure that MH version is greater than 
# or same as that of least supported MH version
my $mh_version = &VRTS::Config::MANIFEST_VERSION;
my_print("Checking if MH version [$mh_version] is same or greater than as that of least supported MH version [$least_sup_mh_ver]\n");
if(1 == _compare_versions($least_sup_mh_ver, $mh_version))
{
    my_print("Older MH version $mh_version is not supported on this CMS version\n");
    exit(0);
}

# putting eval check for Task as it is  
# not supported in pre 3.0 MH 
eval { require VRTS::Task; };
if($@) {
    $TASK_SUPPORTED = 0;
}

GetOptions(\%opts,qw (quiet=s hostname=s domain=s help));

if ($opts{"help"})
{
   usage();
   exit(0);
}

if ($opts{"hostname"}) { $MH_HOSTNAME = $opts{"hostname"} };
if ($opts{"quiet"}) { $quiet = 1 };
if (defined $opts{"domain"} && $opts{"domain"} ne "" ) 
{ 
    if ($mh_version =~ /^[2-3]\.|^4\.0\.1097\.0$/)
    {
        my_print("domain option is supported only with VRTSsfmh package version 4.0RU1 or greater\n");
        exit(1);
    }
    $cs = $opts{"domain"};
};

if($^O =~ /Win32/i)
{
    $atutil_command = "\"". $atutil_command . "\"";
    $perl_command = "\"". $perl_command . "\"";
    $mh_cred = "$appdirmh"."\\mh_cred.xml";
    $sfme = "$perl_command -I\"$installdirmh\\lib\\modules\" "."\"$installdirmh\\web\\admin\\cgi-bin\\sfme.pl\"";
}
else
{
    $mh_cred = "$appdirmh"."/mh_cred.xml";
    $sfme = $sfme_command;
}

sub my_print
{
    my $str = shift;
    VRTS::Logger::log('debug',$str);
    if($quiet == 0)
    {
        print $str; 
    }
}

my_print "\nVeritas InfoScale Operations Manager Managed Host Deployment\n";

my_print "Initializing\n";

$cmd = VRTS::Util::make_command ($xprtlc, "-l", "https://localhost/world/getvitals", "-u", "nobody");
$out = `$cmd`;
if($? != 0)
{
    my_print "Cannot contact xprtld on this host\n";
    my_print "Managed host cannot be configured\n";
    exit(1);
}
$obj = from_json ($out);

$cmd = VRTS::Util::make_command ($xprtlc, "-l", "https://$cs/world/getvitals", "-u", "nobody");
my $cs_vitals = `$cmd`;
if($? != 0)
{
    my_print "Cannot contact central server on $cs\n";
    my_print "Managed host cannot be configured\n";
    exit(1);
}

VRTS::Logger::log('debug',"Managed host version $obj->{XPRTLD_VERSION}");

# Set the hostname to default if not set through cmd line option
if (not defined $MH_HOSTNAME)
{
    my $use_default = 0;

    $obj = from_json ($cs_vitals);
    $MH_HOSTNAME = $obj->{PEER_NAME};
    if(not defined $MH_HOSTNAME or $MH_HOSTNAME eq '' or $MH_HOSTNAME eq 'UNKNOWN')
    {
        $MH_HOSTNAME = $obj->{PEER_ADDR};
    }
}

# Check 2-way connectivity.
my_print "Attempting to configure host using hostname $MH_HOSTNAME.\nVerifying if it is reachable from the CMS $cs...\n";
$cmd = VRTS::Util::make_command ($xprtlc, "-u", "nobody", "-l", "https://$cs/https://$MH_HOSTNAME:5634/world/getvitals");
$out = `$cmd`;
if ($? != 0)
{
    my_print "Cannot contact managed host $MH_HOSTNAME\n";
    my_print "from central server $cs\n";
    my_print "Managed host cannot be configured\n";
    exit(1);
}


# Get the hostid
$hostid = VRTS::OS->get_hostguid();
my $is_memeber = VRTS::Util::make_command($xprtlc,"-l","https://$cs/agent/cgi-bin/is_member.pl",
                                "-d","hostid=$hostid");


my $host_in_enum = 0;
my $host_in_db = 0;

# Figure out if host is already added to domain
$cmd = VRTS::Util::make_command ($xprtlc, "-l", "https://$cs/agent/domain/enum");
$out = `$cmd 2>&1`;
if($? == 0)
{
    if($out =~ /$hostid/)
    {
        $host_in_enum = 1;
    }
}

$out = `$is_memeber 2>&1`;
if ($? == 0)
{
    if ($out =~ /Yes/)
    {
       $host_in_db  = 1;  
    }
 
}
if ($host_in_enum && $host_in_db)
{
    # Assume host is already configured to this CS only if it is both in the DB as well as in enum
    my_print "$MH_HOSTNAME is already part of domain on $cs\n";
    exit(1);
}

my_print "Extracting credential\n";
open(D, ">$mh_cred");
while(<DATA>)
{
    print D "$_";
}
close(D);

my_print "Configuring managed host\n";
my $mode = $ENV{MODE};
$ENV{MODE} = 1; 
my $cmd = "$sfme configure_mh cs-hostname=$cs cs-ip=10.10.2.3 cs-config-name=$cs_config_name mh-hostname=$MH_HOSTNAME agent-password=mgt.example.com auto-config=1";
if($quiet == 1)
{
   system("$cmd 1>$devnull 2>&1 &"); 
   if($? == 0) {
       #add audit entry
       _add_audit_entry();
       #create and update task to FINISHED state on successful completion
       create_task() if ($TASK_SUPPORTED);
       update_task(0, "Add host to VOM MS $cs is successful") if ($TASK_SUPPORTED);
       upload_data ();  
   }   
   exit(0);
}

my $mh_log = File::Spec->catfile($appdirmh,'logs','mhrun.log');
my $out = `$cmd`;
if($? != 0)
{
    if (defined $out)
    {
        if ($out =~ /Error : ([^\n]+)/)
        {
            my $error_code = $1;
            if (defined $error_code)
            {
                $error_code = VRTS::SFMHCAT->$_ for $error_code;
                my $error_msg = VRTS::CGILOCALE::get_msgcat->i18nget($error_code);
                my_print "\n$error_msg" if (defined $error_msg);
            }
        }
    }
    my_print "\nFailed to configure managed host\n";
    my_print "Please refer to the log file $mh_log\n";
    $ENV{MODE} = $mode; 
    exit(1);
}
else
{
    # Check if host is added to the DB.
    my $out_put = `$is_memeber 2>&1`;
    if (($? == 0 && $out_put =~ /No/) || $? != 0)
    {
        # if host is not added to the database then fail the add host and rollback configuration
        if ($? != 0)
        {
            VRTS::Logger::log('debug',"Unable to contact CMS to verify if Host information available in DB: $out_put");
            VRTS::Logger::log('debug',"Looks like configuration was not successful. Rolling it back");
        }
        else
        {
	    if($mh_version !~ /^2./){
		### This is post configure_mh check for duplicate VM_IDs, it is required only for older MHs(<6.1).
		### For latest MH, we check during configure_mh operation through check_duplicate_vmid operation.
		my %virtual_info=();
		VRTS::OS->get_virtual_info(\%virtual_info);
		if(defined $virtual_info{'VMGUID'}){
		    ### If host is VM then do a DB query for duplicate VM_ID
		    ###Doing duplicate VM_ID checks for VMware env only
		    my $mh_vm_id=$virtual_info{'VMGUID'};
		    my $jsondata = JSON::to_json({'VM_ID' => $mh_vm_id,'VMM' => 'VMware'});
		    my ($ret,$out) = VRTS::Util::xprtlc_payload_send("https://$cs:5634/agent/cgi-bin/getdbinfo.pl/hosts", 
								     $jsondata,'application/json');
		  
		    my $obj;
                    if((!defined $out) || ($out eq '')) {
                        VRTS::Logger::log('debug', 'xprtlc payload output is either undefined or empty...proceed without checking for duplicate VMID');
                    } else {                
                        eval {
						    $out = "{}" if (!$out); 
                            $obj = JSON::from_json($out);        
                            1;
                        } or do {
                            $obj = undef;
                            VRTS::Logger::log('debug', "could not convert xprtlc payload output to hash..output is [$out]...proceed without checking for duplicate VMID");
                        };
                    }
		    if(defined $obj){
			my $records = $obj->{Records};
			my $nh = scalar (@$records);
			if($nh){
			    ### If already exist a host with duplicate VM_ID then populate its hostname and type.
			    my $dup_host_type =  $obj->{Records}[0]->{TYPE};
			    my $dup_host_name =  $obj->{Records}[0]->{NAME};
			    if($dup_host_type){
				VRTS::Logger::log('debug',"$MH_HOSTNAME and CMS having same Virtual Machine ID. Please change $MH_HOSTNAME's Virtual Machine ID to proceed further.");
				my_print "$MH_HOSTNAME and CMS having same Virtual Machine ID. Please change Virtual Machine ID of $MH_HOSTNAME to proceed further.\n";
			    }
			    else{
				VRTS::Logger::log('debug',"$dup_host_name is already reporting to CMS having same Virtual Machine ID as $MH_HOSTNAME. Either remove $dup_host_name or change Virtual Machine ID of $MH_HOSTNAME to proceed further.");
				my_print "$dup_host_name is already reporting to CMS having same Virtual Machine ID as $MH_HOSTNAME . Either remove $dup_host_name or change Virtual Machine ID of $MH_HOSTNAME to proceed further.\n";
			    }
			}
			else{
			    VRTS::Logger::log('debug',"Host not found in database post configuration. cleaning up");
			}
		    }
		}
	    }
        }

        $cmd = VRTS::Util::make_command($xprtlc,"-l", "https://$cs/agent/domain/unregister","-d","id=$hostid");
        `$cmd`;

        # ping will cleanup configuration
        $cmd = VRTS::Util::make_command($perl_command,$ping);
        `$cmd`;

        my_print "\nFailed to configure managed host\n";
        my_print "Please refer to the log file $mh_log\n";
        $ENV{MODE} = $mode;
        exit(1);
    }    
    #add audit entry
    _add_audit_entry();
    #create and update task to FINISHED state on successful completion
    create_task() if ($TASK_SUPPORTED);
    update_task(0, "$MH_HOSTNAME successfully configured as a managed host to VOM MS $cs") if ($TASK_SUPPORTED);
    upload_data ();
    my_print "\n$MH_HOSTNAME successfully configured as a managed host\n";
    my_print "and is now reporting to central server on $cs\n";    
}
$ENV{MODE} = $mode; 
exit 0;

sub upload_data
{
    my $mh_ip = $obj->{PEER_ADDR};
    my $cmd = VRTS::Util::make_command ($xprtlc, "-l", "https://$cs/agent/cgi-bin/catalog.pl/refresh/$mh_ip", "1>$devnull", "2>&1");
    system ($cmd);

    #Upload the catalogs and alert declarations.
    my $decl_file = File::Spec->catfile ($appdirmh, "declarations.json.$$");
    eval {
        $cmd = VRTS::Util::make_command ($xprtlc, "-l", "https://localhost/admin/cgi-bin/eventadm.pl/listdecl");
        # Dont report anything if the declarations cant be download.
        open (DATA, "$cmd |") || exit 0;
        my $text = join ("", <DATA>);
        close (DATA);
        my $obj = from_json ($text);
        if ($obj->{"RESULT"}->{"RETURNCODE"} == 0)
        {
            my @decls;
            foreach my $topic (keys(%{$obj->{"RESULT"}->{"RESULT"}->{'declarations'}})) {
                my $decl;
                $decl->{'topic'} = $topic;
                $decl->{'data'} = $obj->{"RESULT"}->{"RESULT"}->{'declarations'}->{$topic};
                push(@decls, $decl);
            }
            my $final = {};
            $final->{'declarations'} =\@decls;
            $text = to_json($final);
        }
        open (DATA, "> $decl_file");
        print DATA $text;
        close (DATA);
        $cmd = VRTS::Util::make_command ($xprtlc, "-l", "https://$cs/agent/cgi-bin/event.pl/declare",
            "-f", "declarations=\@$decl_file", "1>$devnull", "2>&1");
        system($cmd);
    };
    unlink ($decl_file);
}

sub usage
{
    print "$0 [--hostname <hostname>] [--domain <domain>] [--quiet] [--help]\n".
          " This script adds the host to the domain of the VOM Management Server $cs\n".
          " The host must have the VRTSsfmh package installed on it.\n".
          " hostname: This is an optional hostname for the Managed Host as seen by the VOM Management Server $cs\n".
          "           The host will be discovered with this name in the VOM UI.\n".
          " quiet:    If specified the script will not print any messages on console.\n".
          " domain:   Alternate hostname/IP address for the CMS.\n".
          "           This option is supported only if VRTSsfmh package version is 4.0RU1 or greater\n";
}

sub create_task
{
    my @tmp_out_arr; 
    push @tmp_out_arr, 'Host is getting added to VOM MS through gendeploy';
    $task_handler = new VRTS::Task;
    $task_hash{'Name'} = 'Add host';
    $task_hash{'source'} = $cs_config_name;
    $task_hash{'SourceId'} = $cs_guid;
    $task_hash{'state'} = 'RUNNING';    
    $task_hash{'outputs'} = \@tmp_out_arr;
    $task_id = $task_handler->create(undef, \%task_hash);
}

sub update_task
{
    my $rc = shift;
    my $op = shift;
    my @tmp_out_arr; 
    push @tmp_out_arr, $op;
    $task_hash{'state'} = 'FINISHED';
    $task_hash{'exitcodes'} = $rc;    
    $task_hash{'outputs'} = \@tmp_out_arr;
    $task_handler->update($task_id, \%task_hash);     
}

sub _add_audit_entry
{
    my @values = split(/\./, $mh_version);  
    #audit is not available pre 6.0
    if($values[0] < 6) {
        return;
    }
    #though have put version check already
    #putting eval check for more safety
    eval { require VRTS::Audit; };
    if($@) {
        return;
    }    
    my $user_who;
    my $ip_where = $MH_HOSTNAME;
    my $op_what = 'Add host';
    my $op_what_display = 'Add host';
    my $reason_why = undef;
    my $auth_status = undef;
    my $target_name = $MH_HOSTNAME;
    my $target_id = $hostid;

    #Default user
    if($^O =~ /Win32/i) {
        $user_who = 'administrator';
    }
    else {
        $user_who = 'root';
    }
    $user_who = $user_who . '@' . $MH_HOSTNAME;
 
    my $ret_code = VRTS::Audit::logit($user_who, $ip_where,
                       $op_what, $auth_status, $reason_why, $target_id, $target_name);
}

# Input: first version, second version
#           both consist of period separated four fields
#        compare_till - how many fields to compare(default is four)
#   
# Output: returns -1 if first version is lesser than second
#              returns 0 if first version is equal to second
#              returns 1 if first version is greater than second  
sub _compare_versions 
{
    my ($lhs, $rhs, $compare_till) = @_;
    my @lhs_arr = split(/\./, $lhs, 4);
    my @rhs_arr = split(/\./, $rhs, 4);
    my $i;
    $compare_till = 4 if(! $compare_till);
    for ($i = 0; $i < $compare_till; $i++) {
        # return 0 if lhs < rhs
        # return 1 if lhs > rhs
        # continue if lhs == rhs
        ($lhs_arr[$i] < $rhs_arr[$i]) ? return -1 : (($lhs_arr[$i] > $rhs_arr[$i]) ? return 1 : next);
    }
    # return 0 if lhs == rhs
    return 0; 
}
__DATA__
<?xml version="1.0" encoding="US-ASCII" standalone="yes"?>
<profile>
<version>1.0</version>
<date>Wed Aug 30 10:48:04 2017</date>
<iv>WZWTsNpCGWCNV9/TFhVza75YyM5kxC7I6+KUO0JZmLNlh1inqqiclUSbr/B6Sts2mTc4rhZ2ceYUvGJP4XCXWQ==</iv>

<!-- File section -->
<file>
<filename>keystore/PrivKeyFile.pem</filename>
<type>key</type>
<size>2241</size>
<cipherdata_1>XAFPHENCRgFIi4kS3Whjhv7ySXdLX7xuqi0v7X/1AIf7KMy2qmfRL58rCoqNHyQjeM0rBT3e5kH3BfOjsZoEExrhQJM/zH+yNu56Mx/rHQQ4JMQLtp0wpiGdJ7KF+D2hqmeJbf6Q4sxgFEXbhVjBD7QyXc87H5WqojaiBUfYVtcOYjbA6rRApO1aqYjE9vXE8waxNTACeeg4Erv8PaDPOUyp0atYkT0/zxC/z8UbC5GvywJjwJPmNA+9Gz18vroOw4MuZ+M+QVgo/AiAqaH8R3M9XNPN5pVNlrWa2iWrJZtSrd1/cGiOT7crF1G4SjYbuvUEH1lIKosyK/oNs92Dfe70l6aVuJq1/5vOLPjHBHyL5XlOwnbOdeieEtzxrWJvJKoibIXOk9WmDK6gXLTBgQMvffjLJ2p8lQFmCfJY3SpVRJofYonf2O+MZDjofLMnSL19GNf8PHqcsRrFUquotMpQYnf9t88nJE6M2n0DHz7xdoA6A6lC+qV8jxDxAwRTlv9Mk+ChA8hjI6Ozpe9V/ZTfu6Lg7nMr+PxgfXHTM0U9F0/EfxyG1i+EVGKEln/tWnXpB/Z0FR0jk4OBCEqw6neAe9gg4492bJctAmuybn6KfXu8ttImtdjBa+3SC8PMpLXXyrcilFIAC5xHOCIqiKtHqsUTSVLE0GYFSjXn6+i1nujz9antyv8ZJU3JawwB9GiyBAzna//FmHZOQM+9pGr5CyP0O38B9fJUtSeLpzfx96uX/mLRWpfnghb3cVDGhgyyT//9XYqWKw+pJylL/c9r+tmH9wwvzbNIGDQ//Qt90s1lgMqts3OStkNIDz5v9tFTPYlp3tLxf2cL96AYLm8103HMwC23sUVkNTRWIXn5domEXLF8LZHUHqAUHu+eWyCQvt7+m9ETQYwBCgbw73RebR/CWeieij1blMZdI5o95rSg5SrqxR1chdtiRYJuZujTHyPX2zb+8shKw+ptzP0DmnMeQHJIozIdzvYzPFTiSHDEA0lVBDrd1+u1q8CHLkOkpp0EWalai3vEC97EaLX2T6jccnJP1ioiMUCGgg1GZ0W7pF8xgvBPgYln0CGBAdystVIpPizMJ3FPNSP3da4Hjt0kM+eZ0TxsrSzwH6V6nOcf8GYam1FVPffmuG9ItTk+5ejS2G5NEGS4TXesqiNzruEH6n29zJUktl4QTcF9hCEKbQs422t+adp8ZaupZxcaBSVRlyG1BnXrEHCaS/1pcpGrhyoUvYJMzwq/pScCwIO0dq7wIAqH9WxGNWl33ExKPeMgfTYQEqKClmXlLpcm61TAdRlOyEN35+u+c6LkGBnBllmwm7fJp1FOfQvyJNSTemg8MZ+vaMSo5POxpYxrO43U2AGfey4RQ2tEvB8ViIb4uT3R9pRjmKpCCOzrg0ba4+92iAGryF2zJJeCjRjj3MtqlILj2/YEcMEzHJpuysRTP+gIqz4yKGerJzG4KXh0dXigXc+2LonB5TG+1wU/m7cMm13TtclQ/XZF8hMBKLqYfJpiuehoF7fazSkfYpH7EnRyk8bh7tG4jGPfnuJaGo5H+ExT0xpAb58yGzoXP8+F2nYpyVKEKVn99aUAPXRiSdqfirBnsiKuyLm2kSiAopE2O26DMqhIeZStdbqNYpdNlXvYLZfTpp2CBQShndwBbAtiM+6mzw+Bey6qiIQoZNrcIhKi1DoZelhWZyyB1k1hvjM5RvfMgBfqE1xfD8syS7NGTqdFP10SIxh7q3oqAX51McZlfNz4SdB+Sk+HesRbMYa/EQgTxUoky1N+DPfpCcj0eEXDf8mlfNwd2HMkX29DBb24QSfy/VtyeE6zt5rtX/V0Dj31AnOYRwGHNzVQcm+nW+7eRn8319o6uFVZ/J1FYfStW+wcrJEoV3FiQXVRFv/TW9qbSujdcKzUorFPvYcH9kgoqs2nmA79Zogy2FaMITU0JdqIGoxCLf/V0EPSTfXV33OhFnbBXPFSYv4+2D1Pm2cEluc/7x9dKjQYN5hpEouAyCLMF4RwUibq70LrHE/95j1KSIC2rRuM+D+agJB7azKiApICeVODLYjt+Xubl38Xp85C/YSWg4ip3ZSfECTkuzaHb0cnJvvp04cE1xMgOIRUBL6RPpR+FZ8YjZphP28+sMahyGuAWW9e5ZeBtSfvlZ7PENTIyO/n+Pi0IO/28gL0NgSOelzFHUy7zseqBrqfQ0xP6kJTGp/t6OESzWjeClMSoopr5do=</cipherdata_1>
</file>

<!-- File section -->
<file>
<filename>keystore/PubKeyFile.pem</filename>
<type>key</type>
<size>426</size>
<raw>-----BEGIN RSA PUBLIC KEY-----
MIIBCgKCAQEA1bKE1npBCzsA1ULg+jsjGbHidLvlQ3f7FXnM9EBTvFY+UhgnfcZc
YJa4ERPE2o9fkjT8OW4jjrNpD36iAj0lRuB5ZMw+4imncAk8NxZ762EWb3XmQNr2
7KAAmQwFXQC+QPbhp0SNFa05v0c5sP9lUhNmfpEsuOJkmAlaxIJ9jFdb0EN5m1ly
4RwJxs5wDNMA2PxPY1Np1BZql/ao3JBbl5SUcexhw9Tci6Ef7Ru39xYYBhEvHjaE
bmeXv928bOHT+L7VBwa5JqFHWZ8MhYHD5OzkjSkA5DET7e4r84kY0nIbyjcgleVm
TYmMC7ybJSjAc8OwV4fJ5grHx5EjWMSNiwIDAQAB
-----END RSA PUBLIC KEY-----
</raw>
</file>

<!-- File section -->
<file>
<filename>0bac05a6.0</filename>
<type>trustedcred</type>
<size>1269</size>
<raw>-----BEGIN CERTIFICATE-----
MIIDfDCCAmSgAwIBAgIBADANBgkqhkiG9w0BAQsFADBBMRMwEQYDVQQDDApTRk1f
QlJPS0VSMR0wGwYDVQQLDBRyb290QG1ndC5leGFtcGxlLmNvbTELMAkGA1UECgwC
dngwHhcNMTcwMTA1MTMyMzUxWhcNMzYxMjMxMTQzODUxWjBBMRMwEQYDVQQDDApT
Rk1fQlJPS0VSMR0wGwYDVQQLDBRyb290QG1ndC5leGFtcGxlLmNvbTELMAkGA1UE
CgwCdngwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCi2ZZ87bwWTQhE
2hfpm/FstXk+BkPKgt5a37HpRv7hMdcqytWfxqZpztCCvZp52nmrbxw81759QY0x
Do/6hUeL+bs2tgAXs51HV88adlyT+Cj/Syr5KD94+6bu410GOsk5r59skXO/HmaX
vjIjENBYg6vQCOf4qb8JXxKE7zU8UU+h8BbbKel7SANw+Z4dS2l4ZOU07VPCeUtF
oNWdZHB2udqlDHtws1DFH/vCvelBUROD863g/4S/lhHa+xtLrkGD9mC1JjCxTvST
+iW1Ucie2jqFE5FLECFwZMx23P+5lYJUDQP5c0h3ZG5RxPwxiaS9MQgzmj8Rm6rN
mXnqXIvDAgMBAAGjfzB9MA8GA1UdEwEB/wQFMAMBAf8wCwYDKgMFBARyb290MA8G
AyoDBgQIMDAwMDAwMTcwLQYDKgMIBCZ7YWQyMGFmNGEtZDM1NC0xMWU2LTlkNjEt
NGEwOGU3MjI5YmNjfTAdBgNVHQ4EFgQUk6iPL48YwDdILyqfV87y/qcxd+YwDQYJ
KoZIhvcNAQELBQADggEBAHDHW1Xld9A3g/ofOvuM8Ge/h0NwvUm3m1QsllNNnEVD
yiO09VQXzd9rioAF739JFsulCN+NsdeuePr1lHwF9ejO/qWHt23M4KIinIGvoyre
ACLYU0WbEl1iFLkBOQIs7TE6BTWZUfH6qWxNLQjslrFhKjM9d5lmVPcwIqQrbdzY
j3yKVjJCHvgZsspH+ppJpcE0vVc3Fw5sIVZ3EoKVOv2fh4A+9AKziPCVcurqPVmo
aDKXseM630HlOoGKygN34f5ZNfxos4NlIY5LhCZcKfpBl7ui0N5XD0W5ph6PDBqj
27dsFoTIhtpI3awovdLRPVbQ830mO9mQpATQqZ2wLDM=
-----END CERTIFICATE-----
</raw>
</file>

<!-- File section -->
<file>
<filename>f6ff7d7e-mgt.example.com!14545.0</filename>
<type>cred</type>
<size>2636</size>
<raw>-----BEGIN CERTIFICATE-----
MIIDozCCAougAwIBAgIBCTANBgkqhkiG9w0BAQsFADA9MQ8wDQYDVQQDDAZicm9r
ZXIxHTAbBgNVBAsMFHJvb3RAbWd0LmV4YW1wbGUuY29tMQswCQYDVQQKDAJ2eDAe
Fw0xNzAxMDUxMzIzNThaFw0yNzAxMDMxNDM4NThaMEYxEjAQBgNVBAMMCXNmbV9h
Z2VudDEjMCEGA1UECwwac2ZtX2RvbWFpbkBtZ3QuZXhhbXBsZS5jb20xCzAJBgNV
BAoMAnZ4MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA1bKE1npBCzsA
1ULg+jsjGbHidLvlQ3f7FXnM9EBTvFY+UhgnfcZcYJa4ERPE2o9fkjT8OW4jjrNp
D36iAj0lRuB5ZMw+4imncAk8NxZ762EWb3XmQNr27KAAmQwFXQC+QPbhp0SNFa05
v0c5sP9lUhNmfpEsuOJkmAlaxIJ9jFdb0EN5m1ly4RwJxs5wDNMA2PxPY1Np1BZq
l/ao3JBbl5SUcexhw9Tci6Ef7Ru39xYYBhEvHjaEbmeXv928bOHT+L7VBwa5JqFH
WZ8MhYHD5OzkjSkA5DET7e4r84kY0nIbyjcgleVmTYmMC7ybJSjAc8OwV4fJ5grH
x5EjWMSNiwIDAQABo4GkMIGhMAwGA1UdEwEB/wQCMAAwEQYDKgMFBApjcmVkZW50
aWFsMA8GAyoDBgQIMDAwMDAwMTcwLQYDKgMIBCZ7YWQyMGFmNGEtZDM1NC0xMWU2
LTlkNjEtNGEwOGU3MjI5YmNjfTAdBgNVHQ4EFgQUhSjm1XI371IfYd3HrKhgyV06
DJowHwYDVR0jBBgwFoAUu9S9JsNP4qQP3FbX1LVWK4CLc3swDQYJKoZIhvcNAQEL
BQADggEBAHfTiSRANslOvxJYL6VeP5d4h9YV41PBlqbQdisGVLW2nHeP93sUpFdv
qrFd6ERclPfw4d5O9+PNexsBpsG5Tgx5KM3M4uOx/9tSTrYGVlKq0aCkV9kK0x1n
GF696SVfjsFam/9QM+qJWq4cUGaWw14qjeUnjfC6l1fblCWldbRsUITw0p/Kfk1x
tLKrWvhML0wPhDg7Q2dqbGmeEEAJn3btBPmSbcryfIGR3lBhgyUqpSRc/2DsnKMe
FtEjA5cuwL4xrQSBxPNKtVJi0ki+4J8yyZp99gvMGc8pJ3+g2dKoGFghbv+W90/z
dEzzDO1j5Lv9KPmmhupFKVfkqvBBNcY=
-----END CERTIFICATE-----
-----BEGIN CERTIFICATE-----
MIIDnTCCAoWgAwIBAgIBATANBgkqhkiG9w0BAQsFADBBMRMwEQYDVQQDDApTRk1f
QlJPS0VSMR0wGwYDVQQLDBRyb290QG1ndC5leGFtcGxlLmNvbTELMAkGA1UECgwC
dngwHhcNMTcwMTA1MTMyMzUxWhcNMzYxMjMxMTQzODUxWjA9MQ8wDQYDVQQDDAZi
cm9rZXIxHTAbBgNVBAsMFHJvb3RAbWd0LmV4YW1wbGUuY29tMQswCQYDVQQKDAJ2
eDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALIvQwQGwYHYsld8335q
g1g48BIgai+G0AoeD6uLfOIQV1pBUcZLzIXafsAaGelwQx+eR6kvi54aX1XC+v9k
gP14Zw8GvQHQM10iV6G8TrcEmkXrpNXAFYYvDmy5+9/Bv3942nyfjkLEnjJLVNN9
wErdLCxmGPmMSFc+mzqW5RAa07LmXEC83VMofPU4V5Q46jxvQYBpkG0jHGrZwy8v
Zdq6Et2IiBhC1S2ghQj3cO8SSYNEJVJE3D2itGfZuCiD2Syrdt88Cg/FWzHaaGq/
3hIe7KxpovBzehgMymh1M+fQ5DMdcl/NK1PMItOPFLR/dQox8LjmbzG9sa876QXl
nX0CAwEAAaOBozCBoDAPBgNVHRMBAf8EBTADAQH/MA0GAyoDBQQGYnJva2VyMA8G
AyoDBgQIMDAwMDAwMTcwLQYDKgMIBCZ7YWQyMGFmNGEtZDM1NC0xMWU2LTlkNjEt
NGEwOGU3MjI5YmNjfTAdBgNVHQ4EFgQUu9S9JsNP4qQP3FbX1LVWK4CLc3swHwYD
VR0jBBgwFoAUk6iPL48YwDdILyqfV87y/qcxd+YwDQYJKoZIhvcNAQELBQADggEB
AAptNRFS4auXkaVp+rAVcOV4k81igmXZGIKc1QbtAGSvpDYsmI9l8c/l1RaEk8b9
tG22MiG9qtjHIOUHw3/DgNt4W0TRBmF7G/vznPv1MLx5a5pjyoR0WBqEnea+rlaO
7d6ktr9eiPbnAcvEdO9NlTU8qJs7O1PcCHqWuNXPyUOvWLXmcCNBl6utqPdfPO/j
xG1Q/rm3m+HbfrH7a38L4OPfkfgS/P8O595H7/o74Pq7o1WFWKY4lnhqU4ASkc9x
wy4lBP1wMb6EPZ2TRCTq5Gf1BR4VmOgrJpTb+aqUL8HLcjI3suDlVkzeClGXgaGe
Hx1xtwYZX79whI/6dW1Vu2w=
-----END CERTIFICATE-----
</raw>
</file>
<mic1>55a367420ebdaec1e9a02170cd0b1a8c</mic1>
</profile>
