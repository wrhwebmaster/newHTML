#!/usr/bin/perl

# Copyright (c) 2017 Veritas Technologies LLC ALL RIGHTS RESERVED.
# UNPUBLISHED -- RIGHTS RESERVED UNDER THE COPYRIGHT
# LAWS OF THE UNITED STATES. USE OF A COPYRIGHT NOTICE
# IS PRECAUTIONARY ONLY AND DOES NOT IMPLY PUBLICATION
# OR DISCLOSURE.
#
# THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND
# TRADE SECRETS OF VERITAS SOFTWARE. USE, DISCLOSURE,
# OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
# EXPRESS WRITTEN PERMISSION OF VERITAS SOFTWARE.
#
# RESTRICTED RIGHTS LEGEND
# USE, DUPLICATION, OR DISCLOSURE BY THE GOVERNMENT IS
# SUBJECT TO RESTRICTIONS AS SET FORTH IN SUBPARAGRAPH
# (C) (1) (ii) OF THE RIGHTS IN TECHNICAL DATA AND
# COMPUTER SOFTWARE CLAUSE AT DFARS 252.227-7013.

# Set some variables that are needed through the script
# put the variables here .....
use FindBin;
use lib "$FindBin::Bin/../setup/lib";

require 'common_functions.pl';
require 'os_variables.pl';
require 'common_sf.pl';
require 'common_vcs.pl';

$local_sys = qx/uname -n/;
chomp($local_sys);

# Set some OS specific variables
_OS_variables();
$remote_sh = $ssh;

# Determine the LLT links
@is_private = qx/$lltstat -l | grep ether | awk '{print \$3}'/; 
chomp(@is_private);

set_tput();

title("Enable or Disable LLT links Script");

print "This script can be used to enable and disable LLT links on the local\n";
print "system or on all nodes in the cluster.\n";
print "Choose the desired option from the list below.\n\n";
print "\t1. Disable all private links (@is_private) on all nodes in the cluster\n";
print "\t2. Disable all private links (@is_private) on $local_sys only\n";
print "\t3. Enable all private links (@is_private) on $local_sys only\n";
print "\t4. Disable $is_private[0] on $local_sys only\n";
print "\t5. Enable $is_private[0] on $local_sys only\n";
print "\t6. Disable $is_private[1] on $local_sys only\n";
print "\t7. Enable $is_private[1] on $local_sys only\n";
print "\t8. Disable $is_private[2] on $local_sys only\n";
print "\t9. Enable $is_private[2] on $local_sys only\n\n";

print "Which setup do you wish to run? Enter 1 - 9: ";
chomp($_ = <STDIN>);

if (/\b1\b/){

        system ("/usr/bin/tput clear");
        print "\n\n$COMM{TPUT}{SS}  Disable all private links (@is_private) on all nodes in the cluster  $COMM{TPUT}{SE}\n\n";

	_disable_all_lltlinks_allnodes($is_private[0],$is_private[1],$is_private[2]);

}

elsif (/\b2\b/){

        system ("/usr/bin/tput clear");
        print "\n\n$COMM{TPUT}{SS}  Disable all private links (@is_private) on $local_sys only  $COMM{TPUT}{SE}\n\n";

        _disable_lltlinks_local($is_private[0],$is_private[1],$is_private[2]);

}

elsif (/\b3\b/){

        system ("/usr/bin/tput clear");
        print "\n\n$COMM{TPUT}{SS}  Enable all private links (@is_private) on $local_sys only   $COMM{TPUT}{SE}\n\n";

        _enable_lltlinks_local($is_private[0],$is_private[1],$is_private[2]);

}

elsif (/\b4\b/){

        system ("/usr/bin/tput clear");
        print "\n\n$COMM{TPUT}{SS}  Disable $is_private[0] on $local_sys only  $COMM{TPUT}{SE}\n\n";

        _disable_lltlink_local($is_private[0],$local_sys);

}

elsif (/\b5\b/){

        system ("/usr/bin/tput clear");
        print "\n\n$COMM{TPUT}{SS}  Enable $is_private[0] on $local_sys only  $COMM{TPUT}{SE}\n\n";

        _enable_lltlink_local($is_private[0],$local_sys);

}

elsif (/\b6\b/){

        system ("/usr/bin/tput clear");
        print "\n\n$COMM{TPUT}{SS}  Disable $is_private[1] on $local_sys only  $COMM{TPUT}{SE}\n\n";

        _disable_lltlink_local($is_private[1],$local_sys);

}

elsif (/\b7\b/){

        system ("/usr/bin/tput clear");
        print "\n\n$COMM{TPUT}{SS}  Enable $is_private[1] on $local_sys only  $COMM{TPUT}{SE}\n\n";

        _enable_lltlink_local($is_private[1],$local_sys);

}

elsif (/\b8\b/){

        system ("/usr/bin/tput clear");
        print "\n\n$COMM{TPUT}{SS}  Disable $is_private[2] on $local_sys only  $COMM{TPUT}{SE}\n\n";

        _disable_lltlink_local($is_private[2],$local_sys);

}

elsif (/\b9\b/){

        system ("/usr/bin/tput clear");
        print "\n\n$COMM{TPUT}{SS}  Enable $is_private[2] on $local_sys only  $COMM{TPUT}{SE}\n\n";

        _enable_lltlink_local($is_private[2],$local_sys);

}
else {

        print "\nYou did not enter 1 - 9.  Please try running the script again\n";

}

