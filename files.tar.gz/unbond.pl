#!/usr/bin/perl

# Copyright (c) 2017 Veritas Technologies LLC ALL RIGHTS RESERVED.
# UNPUBLISHED -- RIGHTS RESERVED UNDER THE COPYRIGHT
# LAWS OF THE UNITED STATES. USE OF A COPYRIGHT NOTICE
# IS PRECAUTIONARY ONLY AND DOES NOT IMPLY PUBLICATION
# OR DISCLOSURE.
#
# THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND
# TRADE SECRETS OF VERITAS SOFTWARE. USE, DISCLOSURE,
# OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
# EXPRESS WRITTEN PERMISSION OF VERITAS SOFTWARE.
#
# RESTRICTED RIGHTS LEGEND
# USE, DUPLICATION, OR DISCLOSURE BY THE GOVERNMENT IS
# SUBJECT TO RESTRICTIONS AS SET FORTH IN SUBPARAGRAPH
# (C) (1) (ii) OF THE RIGHTS IN TECHNICAL DATA AND
# COMPUTER SOFTWARE CLAUSE AT DFARS 252.227-7013.

# Set some variables that are needed through the script
# put the variables here .....
use FindBin;
use lib "$FindBin::Bin/../setup/lib";

require 'common_functions.pl';
require 'os_variables.pl';
require 'common_sf.pl';
require 'common_vcs.pl';
require 'common_install.pl';
require 'config_functions.pl';

$local_sys = qx/uname -n/;
chomp($local_sys);

# Set some OS specific variables
_OS_variables();
$remote_sh = $ssh;

set_tput();

$systems = "sys1 sys2 sys3 sys4";
print "Unconfiguring bonding on sys1.\n\n";
if ($local_sys eq "sys1"){  
        system("/sbin/ifdown bond0");
        system("echo '-bond0'>/sys/class/net/bonding_masters");
        system("/sbin/modprobe -r bonding");
	system("$rm -f /etc/sysconfig/network-scripts/ifcfg-bond0");
	system("$cp /student/labs/is/is73/vcsadv/mnic_ips/ifcfg-ens256.orig /etc/sysconfig/network-scripts/ifcfg-ens256");
	system("$cp /student/labs/is/is73/vcsadv/mnic_ips/ifcfg-ens257.orig /etc/sysconfig/network-scripts/ifcfg-ens257");
	system("/sbin/ifup ens256");
	system("/sbin/ifup ens257");
} else {                                                        
        system("$remote_sh sys1 /sbin/ifdown bond0");
        system("$remote_sh sys1 \"echo '-bond0'>/sys/class/net/bonding_masters\"");
        system("$remote_sh sys1 /sbin/modprobe -r bonding");
	system("$remote_sh sys1 $rm -f /etc/sysconfig/network-scripts/ifcfg-bond0");
	system("$remote_sh sys1 $cp /student/labs/is/is73/vcsadv/mnic_ips/ifcfg-ens256.orig /etc/sysconfig/network-scripts/ifcfg-ens256");
	system("$remote_sh sys1 $cp /student/labs/is/is73/vcsadv/mnic_ips/ifcfg-ens257.orig /etc/sysconfig/network-scripts/ifcfg-ens257");
	system("$remote_sh sys1 /sbin/ifup ens256");
	system("$remote_sh sys1 /sbin/ifup ens257");
}               

print "Unconfiguring bonding on sys2.\n\n";
if ($local_sys eq "sys2"){  
        system("/sbin/ifdown bond0");
        system("echo '-bond0'>/sys/class/net/bonding_masters");
        system("/sbin/modprobe -r bonding");
	system("$rm -f /etc/sysconfig/network-scripts/ifcfg-bond0");
	system("$cp /student/labs/is/is73/vcsadv/mnic_ips/ifcfg-ens256.orig /etc/sysconfig/network-scripts/ifcfg-ens256");
	system("$cp /student/labs/is/is73/vcsadv/mnic_ips/ifcfg-ens257.orig /etc/sysconfig/network-scripts/ifcfg-ens257");
	system("/sbin/ifup ens256");
	system("/sbin/ifup ens257");
} else {                                                        
        system("$remote_sh sys2 /sbin/ifdown bond0");
        system("$remote_sh sys2 \"echo '-bond0'>/sys/class/net/bonding_masters\"");
        system("$remote_sh sys2 /sbin/modprobe -r bonding");
	system("$remote_sh sys2 $rm -f /etc/sysconfig/network-scripts/ifcfg-bond0");
	system("$remote_sh sys2 $cp /student/labs/is/is73/vcsadv/mnic_ips/ifcfg-ens256.orig /etc/sysconfig/network-scripts/ifcfg-ens256");
	system("$remote_sh sys2 $cp /student/labs/is/is73/vcsadv/mnic_ips/ifcfg-ens257.orig /etc/sysconfig/network-scripts/ifcfg-ens257");
	system("$remote_sh sys2 /sbin/ifup ens256");
	system("$remote_sh sys2 /sbin/ifup ens257");
}               
