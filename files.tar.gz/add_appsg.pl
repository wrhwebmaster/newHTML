#!/usr/bin/perl

# Copyright (c) 2017 Veritas Technologies LLC ALL RIGHTS RESERVED.
# UNPUBLISHED -- RIGHTS RESERVED UNDER THE COPYRIGHT
# LAWS OF THE UNITED STATES. USE OF A COPYRIGHT NOTICE
# IS PRECAUTIONARY ONLY AND DOES NOT IMPLY PUBLICATION
# OR DISCLOSURE.
#
# THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND
# TRADE SECRETS OF VERITAS SOFTWARE. USE, DISCLOSURE,
# OR REPRODUCTION IS PROHIBITED WITHOUT THE PRIOR
# EXPRESS WRITTEN PERMISSION OF VERITAS SOFTWARE.
#
# RESTRICTED RIGHTS LEGEND
# USE, DUPLICATION, OR DISCLOSURE BY THE GOVERNMENT IS
# SUBJECT TO RESTRICTIONS AS SET FORTH IN SUBPARAGRAPH
# (C) (1) (ii) OF THE RIGHTS IN TECHNICAL DATA AND
# COMPUTER SOFTWARE CLAUSE AT DFARS 252.227-7013.

# Set some variables that are needed through the script
# put the variables here .....
use FindBin;
use lib "$FindBin::Bin/../setup/lib";

require 'common_functions.pl';
require 'os_variables.pl';
require 'common_sf.pl';
require 'common_vcs.pl';
require 'common_install.pl';
require 'config_functions.pl';

$local_sys = qx/uname -n/;
chomp($local_sys);

# Set some OS specific variables
_OS_variables();
$remote_sh = $ssh;

set_tput();

$systems = "sys1 sys2 sys3 sys4";
print "Adding the appsg service group with appfoo resource.\n\n";
_db_makerw("sys1");
if ($local_sys eq "sys1"){
	_do("$hagrp -add appsg");
	_do("$hagrp -modify appsg SystemList sys4 0 sys3 1 sys2 2 sys1 3");
	_do("$hagrp -modify appsg AutoStartList sys4 sys3 sys2 sys1");
	_do("$hares -add appfoo FileOnOff appsg");
	_do("$hares -modify appfoo PathName /var/tmp/appfoo");
	_do("$hares -modify appfoo Enabled 1");
	`sleep 5`;
	_do("$hagrp -online appsg -sys sys4");
} else {
	_do("$remote_sh sys1 $hagrp -add appsg");
	_do("$remote_sh sys1 $hagrp -modify appsg SystemList sys4 0 sys3 1 sys2 2 sys1 3");
	_do("$remote_sh sys1 $hagrp -modify appsg AutoStartList sys4 sys3 sys2 sys1");
	_do("$remote_sh sys1 $hares -add appfoo FileOnOff appsg");
	_do("$remote_sh sys1 $hares -modify appfoo PathName /var/tmp/appfoo");
	_do("$remote_sh sys1 $hares -modify appfoo Enabled 1");
	`sleep 5`;
	_do("$remote_sh sys1 $hagrp -online appsg -sys sys4");
}
_db_makero("sys1");
